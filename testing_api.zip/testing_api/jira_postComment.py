import requests
from requests.auth import HTTPBasicAuth
import json
import sys

Issue_key = sys.argv[1]
comment_text = sys.argv[2] if len(sys.argv) > 2 else "No output provided."

url = f"https://vibhaa.atlassian.net/rest/api/3/issue/{Issue_key}/comment"

auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")

headers = {
  "Accept": "application/json",
  "Content-Type": "application/json"
}

payload = json.dumps( {
  "body": {
    "content": [
      {
        "content": [
          {
            "text": comment_text,
            "type": "text"
          }
        ],
        "type": "paragraph"
      }
    ],
    "type": "doc",
    "version": 1
  }
} )

response = requests.request(
   "POST",
   url,
   data=payload,
   headers=headers,
   auth=auth
)

print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))