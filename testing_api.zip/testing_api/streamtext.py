import streamlit as st
import requests
import json

def render():
    st.title("Site Validator")

    task_input = st.text_area("Enter Task Instructions:", height=300)
    # sender_id = st.text_input("Enter Sender ID (optional):", value="")

    if st.button("Run Validation"):
        if task_input.strip():
            try:
                # Prepare POST request body
                request_body = {"input_text": task_input}
                # if sender_id:
                #     request_body["sender_id"] = sender_id

                # Send POST request to FastAPI service
                response = requests.post(
                    "http://localhost:8000/run_text_task/",
                    json=request_body
                )
                response.raise_for_status()
                data = response.json()

                # Extract results
                input_text = data.get("input_text", "Input not found")
                output = data.get("output", "No output")
                error = data.get("error", None)
                status = data.get("status", "Unknown")
                sender_id_returned = data.get("sender_id", "N/A")

                # Display results
                st.text_area("Task Instructions:", value=input_text, height=100)
                st.markdown("---")
                st.subheader("Validation Output:")
                st.code(output)
                if error:
                    st.error(f"Validation Errors:\n{error}")
                # st.markdown("---")
                # st.subheader("Status:")
                # st.write(status)
                # st.markdown("---")
                # st.subheader("Sender ID:")
                # st.write(sender_id_returned)

            except requests.exceptions.RequestException as e:
                st.error(f"Failed to run validation: {str(e)}")
        else:
            st.warning("Please enter task instructions before running.")