import streamlit as st
import requests
import json

def render():
    st.title("Jira Integrated Testing")

    issue_key = st.text_input("Enter Jira Issue Key:", value="TESTING-1")
    # sender_id = st.text_input("Enter Sender ID (optional):", value="")  # Optional sender_id input

    if st.button("Run Test"):
        try:
            # Prepare POST request body
            request_body = {"issue_key": issue_key}
            # if sender_id:
            #     request_body["sender_id"] = sender_id

            # Send POST request to FastAPI service
            response = requests.post(
                "http://localhost:8000/run_jira_test/",
                json=request_body
            )
            response.raise_for_status()  # Raise an error for bad status codes
            data = response.json()

            # Extract results
            summary = data.get("summary", "Summary not found")
            test_output = data.get("test_output", "No test output")
            test_error = data.get("test_error", None)
            test_status = data.get("test_status", "Unknown")
            sender_id_returned = data.get("sender_id", "N/A")

            # Display results
            st.text_area("Issue Summary:", value=summary, height=100)
            st.markdown("---")
            st.subheader("Test Output:")
            st.code(test_output)
            if test_error:
                st.error(f"Test Errors:\n{test_error}")
            # st.markdown("---")
            # st.subheader("Test Status:")
            # st.write(test_status)
            # st.markdown("---")
            # st.subheader("Sender ID:")
            # st.write(sender_id_returned)

        except requests.exceptions.RequestException as e:
            st.error(f"Failed to run test: {str(e)}")

if __name__ == "__main__":
    render()

