# import requests
# from requests.auth import HTTPBasicAuth
# import json

# url = "https://vibhaa.atlassian.net/rest/api/3/search"

# auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")

# headers = {
#     "Accept": "application/json"
# }

# # Example JQL to get all issues from a project
# query = {
#     'jql': 'project = TESTING',
#     'maxResults': 100,
#     'fields': 'id,key,summary,status,priority,created,updated'
# }

# response = requests.get(url, headers=headers, auth=auth, params=query)

# data = response.json()

# for issue in data['issues']:
#     print(f"ID: {issue['id']}")
#     print(f"Key: {issue['key']}")
#     print(f"Summary: {issue['fields']['summary']}")
#     print(f"Status: {issue['fields']['status']['name']}")
#     print(f"Priority: {issue['fields']['priority']['name']}")
#     print(f"Created: {issue['fields']['created']}")
#     print(f"Updated: {issue['fields']['updated']}")
#     print('-' * 40)
##########################################################################################################
# With description extraction from ADF format
import requests
from requests.auth import HTTPBasicAuth
import json

# 1. Set Jira API URL and Auth
url = "https://vibhaa.atlassian.net/rest/api/3/search"
auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")

headers = {
    "Accept": "application/json"
}

# 2. Define JQL Query and Fields
query = {
    'jql': 'project = TESTING',
    'maxResults': 50,
    'fields': 'id,key,summary,status,priority,created,updated,description'
}

# 3. Function to extract plain text lines from ADF Description
def extract_text_from_adf(adf_description):
    lines = []
    if not adf_description:
        return lines

    for block in adf_description.get("content", []):
        if block["type"] == "paragraph":
            current_line = ""
            for item in block.get("content", []):
                if item["type"] == "text":
                    current_line += item.get("text", "")
                elif item["type"] == "hardBreak":
                    lines.append(current_line.strip())
                    current_line = ""
            if current_line:
                lines.append(current_line.strip())
    return lines

# 4. Make the API call
response = requests.get(url, headers=headers, auth=auth, params=query)
issues = response.json().get("issues", [])

# 5. Display results
for issue in issues:
    fields = issue["fields"]
    print(f"ID: {issue['id']}")
    print(f"Key: {issue['key']}")
    print(f"Summary: {fields.get('summary')}")
    print(f"Status: {fields.get('status', {}).get('name')}")
    print(f"Priority: {issue['fields']['priority']['name']}")
    print(f"Created: {fields.get('created')}")
    print(f"Updated: {fields.get('updated')}")

    # Extract and print description lines
    description = fields.get('description')
    lines = extract_text_from_adf(description)
    if lines:
        print("Description:")
        for line in lines:
            print(f"  - {line}")
    else:
        print("Description: (none)")

    print('-' * 50)
