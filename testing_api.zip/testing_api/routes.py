import logging
import time
import json
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from jira_api_service import jira_api_service
from text_api_service import text_api_service
from voice_api_service import voice_api_service
from jira_tasklist_service import get_jira_tasks

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Create FastAPI app
app = FastAPI()

# Add CORS middleware to allow Streamlit requests
origins = [
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Custom HTTP middleware for logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    body_bytes = await request.body()
    request._body = body_bytes
    sender_id = "N/A"
    if request.method == "POST":
        try:
            body_json = json.loads(body_bytes.decode("utf-8"))
            sender_id = body_json.get("sender_id", "N/A")
        except Exception as e:
            logger.warning(f"Failed to parse body: {e}")
    response = await call_next(request)
    duration = time.time() - start_time
    logger.info(
        f"{request.client.host} - {request.method} {request.url.path} - "
        f"sender_id={sender_id} - {response.status_code} - {duration:.2f}s"
    )
    return response

# Pydantic model for Jira test request
class JiraTestRequest(BaseModel):
    issue_key: str
    sender_id: str | None = None

# Pydantic model for text task request
class TextTaskRequest(BaseModel):
    input_text: str
    sender_id: str | None = None

class VoiceTaskRequest(BaseModel):
    input_text: str
    sender_id: str | None = None

# Pydantic model for Jira task list request
class JiraTaskListRequest(BaseModel):
    project_id: str
    sender_id: str | None = None

# Endpoint to run Jira test
@app.post("/run_jira_test/")
async def run_jira_test_endpoint(request: JiraTestRequest):
    """
    Run Jira test by calling jira_api_service.
    Expects a POST request with JSON body containing issue_key and optional sender_id.
    Example: POST http://localhost:8000/run_jira_test/ with body {"issue_key": "TESTING-1", "sender_id": "user123"}
    Returns the summary, test output, and status.
    """
    return jira_api_service(request)

# Endpoint to run text task
@app.post("/run_text_task/")
async def run_text_task_endpoint(request: TextTaskRequest):
    """
    Run text task by calling text_api_service.
    Expects a POST request with JSON body containing input_text and optional sender_id.
    Example: POST http://localhost:8000/run_text_task/ with body {"input_text": "Validate login page", "sender_id": "user123"}
    Returns the output, errors, and status.
    """
    return text_api_service(request)

@app.post("/run_voice_task/")
async def run_voice_task_endpoint(request: VoiceTaskRequest):
    """
    Run voice task by calling voice_api_service.
    Expects a POST request with JSON body containing input_text and optional sender_id.
    Example: POST http://localhost:8000/run_voice_task/ with body {"input_text": "go to petstore swagger.io and serach by id 1", "sender_id": "user123"}
    Returns the output, errors, and status.
    """
    return voice_api_service(request)

# Endpoint to get Jira task list
@app.post("/jira_tasklist/")
async def jira_tasklist_endpoint(request: JiraTaskListRequest):
    """
    Fetch all Jira tasks for a given project ID.
    Example: POST http://localhost:8000/jira_tasklist/ with body {"project_id": "TESTING"}
    """
    try:
        tasks = get_jira_tasks(request.project_id)
        return {"tasks": tasks, "status": "success"}
    except Exception as e:
        return {"error": str(e), "status": "error"}
# Run the server: uvicorn routes:app --reload