import subprocess
import sys
import logging
from fastapi import HTTPException
from pydantic import BaseModel
import os

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Pydantic model for voice task request
class VoiceTaskRequest(BaseModel):
    input_text: str
    sender_id: str | None = None

def voice_api_service(request: VoiceTaskRequest):
    input_text = request.input_text
    try:
        logger.info(f"Running swagwithstream.py with input: {input_text}")
        result = subprocess.run(
            [sys.executable, "swagwithstream.py", input_text],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd="C:/Users/SVibhaa/Documents/CODE/testing_api",
            env={**os.environ, "pythonioencoding": "utf-8"}
        )
        output = result.stdout.strip()
        error = result.stderr.strip() if result.stderr else None
        status = "Success" if result.returncode == 0 else "Failed"
        logger.info(f"Task status: {status}")
        if error:
            logger.error(f"Task errors: {error}")
        return {
            "input_text": input_text,
            "output": output,
            "error": error,
            "status": status,
            "sender_id": request.sender_id or "N/A"
        }
    except subprocess.SubprocessError as e:
        logger.error(f"Subprocess error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Subprocess error: {str(e)}")
    except Exception as e:
        logger.error(f"Server error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")