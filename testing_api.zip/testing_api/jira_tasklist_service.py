import requests
from requests.auth import HTTPBasicAuth
import os

def get_jira_tasks(project_id: str):
    url = "https://vibhaa.atlassian.net/rest/api/3/search"
    auth = HTTPBasicAuth(os.environ["JIRA_USER"], os.environ["JIRA_TOKEN"])
    headers = {"Accept": "application/json"}
    query = {
        'jql': f'project = {project_id}',
        'maxResults': 50,
        'fields': 'id,key,summary,status,priority,created,updated,description'
    }
    response = requests.get(url, headers=headers, auth=auth, params=query)
    response.raise_for_status()
    issues = response.json().get("issues", [])
    results = []
    for issue in issues:
        fields = issue["fields"]
        results.append({
            "id": issue["id"],
            "key": issue["key"],
            "summary": fields.get("summary"),
            "status": fields.get("status", {}).get("name"),
            "priority": fields.get("priority", {}).get("name"),
            "created": fields.get("created"),
            "updated": fields.get("updated"),
            "description": fields.get("description"),
        })
    return results