# # streamlit UI for voice input for file swagwithstream.py
# import streamlit as st
# from audiorecorder import audiorecorder
# import tempfile
# import speech_recognition as sr
# import subprocess
# import sys
# from io import BytesIO
# import os

# st.title("SpeakTest")

# audio = audiorecorder("Click to record", "Recording...")

# if len(audio) > 0:
#     # Convert AudioSegment to bytes for streamlit playback
#     buffer = BytesIO()
#     audio.export(buffer, format="wav")
#     st.audio(buffer.getvalue(), format="audio/wav")

#     # Save audio to a temp file
#     with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
#         audio.export(f.name, format="wav")
#         audio_path = f.name

#     # Recognize speech from audio file
#     recognizer = sr.Recognizer()
#     with sr.AudioFile(audio_path) as source:
#         audio_data = recognizer.record(source)
#         try:
#             text = recognizer.recognize_google(audio_data)
#             st.success(f"Recognized: {text}")

#             # Call swagwithstream.py as subprocess, passing text as argument
#             result = subprocess.run(
#                 [sys.executable, "swagwithstream.py", text],
#                 capture_output=True,
#                 text=True,
#                 encoding="utf-8",
#                 check=True,
#                 cwd="D:/Code/testing",
#                 env={**os.environ, "pythonioencoding": "utf-8"}
#             )
#             if result.returncode == 0:
#               st.code(result.stdout)
#             else:
#              st.error(f"Script error:\n{result.stderr}")
#         except Exception as e:
#             st.error(f"Speech recognition failed: {e}")

##############################################################################################################################
# With editable text area and submit button
# import streamlit as st
# from audiorecorder import audiorecorder
# import tempfile
# import speech_recognition as sr
# import subprocess
# import sys
# from io import BytesIO
# import os

# st.title("SpeakTest")

# audio = audiorecorder("Click to record", "Recording...")

# if len(audio) > 0:
#     # Convert AudioSegment to bytes for streamlit playback
#     buffer = BytesIO()
#     audio.export(buffer, format="wav")
#     st.audio(buffer.getvalue(), format="audio/wav")

#     # Save audio to a temp file
#     with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
#         audio.export(f.name, format="wav")
#         audio_path = f.name

#     # Recognize speech from audio file
#     recognizer = sr.Recognizer()
#     with sr.AudioFile(audio_path) as source:
#         audio_data = recognizer.record(source)
#         try:
#             text = recognizer.recognize_google(audio_data)
#             st.success("Speech recognition successful")
#         except Exception as e:
#             st.error(f"Speech recognition failed: {e}")
#             text = ""  # Default to empty if failed

#     # Allow user to edit or confirm the recognized text
#     editable_text = st.text_area("Edit or enter the text below:", value=text, height=100)

#     if st.button("Submit"):
#         try:
#             result = subprocess.run(
#                 [sys.executable, "swagwithstream.py", editable_text],
#                 capture_output=True,
#                 text=True,
#                 encoding="utf-8",
#                 check=True,
#                 cwd="D:/Code/testing",
#                 env={**os.environ, "pythonioencoding": "utf-8"}
#             )
#             if result.returncode == 0:
#                 st.code(result.stdout)
#             else:
#                 st.error(f"Script error:\n{result.stderr}")
#         except Exception as ex:
#             st.error(f"Failed to run script: {ex}")
##############################################################################################################################
# Calling from unifiedstream.py so adding the render function here
def render():
    import streamlit as st
    from audio_recorder_streamlit import audio_recorder
    import tempfile
    import requests
    from pydub import AudioSegment
    import speech_recognition as sr
    import subprocess
    import sys
    from io import BytesIO
    import os
    import whisper

    st.title("SpeakTest")

    audio = audio_recorder("Click to record", "Recording...")

    # if len(audio) > 0:
    if audio is not None and len(audio) > 0:
        # Convert AudioSegment to bytes for streamlit playback
        audio = AudioSegment.from_file(BytesIO(audio), format="wav")       
        buffer = BytesIO()
        audio.export(buffer, format="wav")
        st.audio(buffer.getvalue(), format="audio/wav")

        # Save audio to a temp file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            audio.export(f.name, format="wav")
            audio_path = f.name

        # Recognize speech from audio file using Whisper
        try:
            model = whisper.load_model("base")  # or "small", "medium", "large"
            result = model.transcribe(audio_path)
            text = result["text"]
            st.success("Whisper transcription successful")
        except Exception as e:
            st.error(f"Whisper transcription failed: {e}")
            text = ""  # Default to empty if failed

        # Allow user to edit or confirm the recognized text
        editable_text = st.text_area("Edit or enter the text below:", value=text, height=100)

        if st.button("Submit"):
            try:
                request_body = {"input_text": editable_text}
                if st.session_state.get("sender_id"):
                    request_body["sender_id"] = st.session_state.get("sender_id")
                # Send POST request to FastAPI service
                response = requests.post(
                    "http://localhost:8000/run_voice_task/",
                    json=request_body
                )
                response.raise_for_status()
                data = response.json()
                # Extract results
                input_text = data.get("input_text", "Input not found")
                output = data.get("output", "No output")
                error = data.get("error", None)
                status = data.get("status", "Unknown")
                sender_id_returned = data.get("sender_id", "N/A")
                # Display results
                st.text_area("Task Instructions:", value=input_text, height=100)
                st.markdown("---")
                st.subheader("Validation Output:")
                st.code(output)
               
                # if result.returncode == 0:
                #     st.code(result.stdout)
                # else:
                #     st.error(f"Script error:\n{result.stderr}")
            except Exception as ex:
                st.error(f"Failed to run script: {ex}")
            
