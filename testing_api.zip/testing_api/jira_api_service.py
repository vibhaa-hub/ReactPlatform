import subprocess
import sys
import logging
from fastapi import HTTPException
from pydantic import BaseModel

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Pydantic model for Jira test request
class JiraTestRequest(BaseModel):
    issue_key: str
    sender_id: str | None = None

def jira_api_service(request: JiraTestRequest):
    issue_key = request.issue_key
    try:
        # Step 1: Run jira_getTask.py to get the summary
        logger.info(f"Running jira_getTask.py for issue key: {issue_key}")
        result_get_task = subprocess.run(
            [sys.executable, "jira_getTask.py", issue_key],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd="C:/Users/SVibhaa/Documents/CODE/testing_api"
        )
        if result_get_task.returncode != 0:
            logger.error(f"jira_getTask.py failed: {result_get_task.stderr}")
            raise HTTPException(
                status_code=500,
                detail=f"Error running jira_getTask.py: {result_get_task.stderr}"
            )
        summary = result_get_task.stdout.strip()
        if "Error" in summary or not summary:
            logger.error(f"Invalid Jira summary: {summary}")
            raise HTTPException(
                status_code=404,
                detail=f"Jira issue not found or invalid: {summary}"
            )
        # Step 2: Run jirawithstream.py with the summary and issue key
        logger.info(f"Running jirawithstream.py with summary: {summary}")
        result_with_stream = subprocess.run(
            [sys.executable, "jirawithstream.py", summary, issue_key],
            capture_output=True,
            text=True,
            encoding="utf-8",
            cwd="C:/Users/SVibhaa/Documents/CODE/testing_api"
        )
        test_output = result_with_stream.stdout.strip()
        test_error = result_with_stream.stderr.strip() if result_with_stream.stderr else None
        test_status = "Success" if result_with_stream.returncode == 0 else "Failed"
        logger.info(f"Test status: {test_status}")
        if test_error:
            logger.error(f"Test errors: {test_error}")
        return {
            "issue_key": issue_key,
            "summary": summary,
            "test_output": test_output,
            "test_error": test_error,
            "test_status": test_status,
            "sender_id": request.sender_id or "N/A"
        }
    except subprocess.SubprocessError as e:
        logger.error(f"Subprocess error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Subprocess error: {str(e)}")
    except Exception as e:
        logger.error(f"Server error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")