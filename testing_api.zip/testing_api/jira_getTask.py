# import requests
# from requests.auth import HTTPBasicAuth
# import json

# url = "https://vibhaa.atlassian.net/rest/api/3/search"
# auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")
# headers = {
#   "Accept": "application/json"
# }
# query = {
#   'jql': 'project = Testing'
# }
# response = requests.request(
#    "GET",
#    url,
#    headers=headers,
#    params=query,
#    auth=auth
# )
# print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))

# import requests
# from requests.auth import HTTPBasicAuth
# import json

# Issue_key="TESTING-1"
# url = f"https://vibhaa.atlassian.net/rest/api/3/issue/{Issue_key}"

# auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")
# headers = {
#   "Accept": "application/json"
# }

# response = requests.request(
#    "GET",
#    url,
#    headers=headers,
#    auth=auth
# )

# print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))


import requests
from requests.auth import HTTPBasicAuth
import json
import sys

Issue_key = sys.argv[1]
url = f"https://vibhaa.atlassian.net/rest/api/3/issue/{Issue_key}"

auth = HTTPBasicAuth("vibhaa.s@outlook.com", "ATATT3xFfGF0zhhEM172Qaylligkc2qRGadXHMx7suQpnXFhyYHJWGxCwx76sSlmLcrEsJsfQF0JauNnO97pg73X1btvY4kbwUPAnvxwsPIc4QpgDy2wFaL04gwFeV3sF2O1ywxBbfYZcGm5GBqbQEJJ5xTb0_-pw0MrFtP8kbCoMaL8vZxaSIY=5FC6C0DA")
headers = {
  "Accept": "application/json"
}

response = requests.request(
   "GET",
   url,
   headers=headers,
   auth=auth
)

data = response.json()
if "fields" in data and "summary" in data["fields"]:
    print(data["fields"]["summary"])
else:
    print("Summary not found or issue does not exist.")