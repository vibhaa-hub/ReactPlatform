#Jira testing with jira called from streamlit(streamjira.py)
import os
import asyncio
import sys
import subprocess

from browser_use.agent.service import Agent
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import SecretStr

import warnings
warnings.filterwarnings("ignore", category=ResourceWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

os.environ["GOOGLE_API_KEY"] = "AIzaSyDPEyK11qj0DqcofL9s0yIOKY03dmDuiJE"

async def sitevalidation() :
    os.environ['GOOGLE_API_KEY'] =  "AIzaSyDPEyK11qj0DqcofL9s0yIOKY03dmDuiJE"

    if len(sys.argv) > 1:
       task = sys.argv[1]
    else:
       print("No task provided.")
       sys.exit(1)
    googleApiKey = SecretStr(os.environ['GOOGLE_API_KEY'])
    googleLlmModel = 'gemini-2.0-flash-exp'

    llm = ChatGoogleGenerativeAI(model=googleLlmModel,api_key=googleApiKey)
    agent = Agent(task=task, llm=llm, use_vision=True)
    history = await agent.run()
    print("Test is completed without assertion")
    print("Test has executed for " + str(history.total_duration_seconds()) + " seconds")
    history.save_to_file(filepath='./test_history.json')
    result = history.final_result()

    print("Test Results:")
    print("#############")
    print("result: " + str(result))

    # Post the result as a comment to the Jira issue
    if len(sys.argv) > 2:
     issue_key = sys.argv[2]
    else:
     issue_key = None

    if issue_key:
     try:
        # Truncate result if too long for Jira comment
        comment_text = str(result)[:32000]
        subprocess.run(
            [sys.executable, "jira_postComment.py", issue_key, comment_text],
            cwd="C:/Users/SVibhaa/Documents/CODE/testing_api"
        )
        print(f"Posted result as comment to Jira issue {issue_key}")
     except Exception as e:
        print(f"Failed to post comment to Jira: {e}")
    else:
        print("No issue key provided, skipping Jira comment.")

    # Print the errors
    errors = history.errors()
    if errors:
        print("Errors:")
        for error in errors:
            print(error)
    else:
        print("No errors found.")

asyncio.run(sitevalidation()) 