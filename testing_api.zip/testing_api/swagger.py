#Swagger testing without voice without streamlit
from langchain_google_genai import ChatGoogleGenerativeAI
from browser_use import Agent
from dotenv import load_dotenv
import os

# Load environment variables from .env file (should include GOOGLE_API_KEY)
load_dotenv()
os.environ["GOOGLE_API_KEY"] = "AIzaSyD_XlPBAeyjRsu6XvMlsvmf5k4_7_CYLgE"

import asyncio

async def main():
    # Initialize Gemini model from LangChain wrapper
    llm = ChatGoogleGenerativeAI(model='gemini-2.0-flash-exp')

    # Define your plain English task / user story
    user_story = """
    You are a test automation assistant. Generate Browser Use framework script code from this user story:

    Test the Swagger Petstore GET /pet/findByStatus endpoint:
    - Open https://petstore.swagger.io/#/
    - Scroll to pet section
    - Expand GET /pet/findByStatus
    - Click Try it out
    - Enter status as 'available'
    - Click Execute
    - Verify the response code is 200
    - Verify response body contains the word 'id'

    Output only the Browser Use code snippet.
    """

    # Create the Browser Use agent with the task and model
    agent = Agent(task=user_story, llm=llm)

    # Run the agent to get generated automation script
    result = await agent.run()

    print("Generated Browser Use Automation Script:\n")
    print(result)

if __name__ == "__main__":
    asyncio.run(main())