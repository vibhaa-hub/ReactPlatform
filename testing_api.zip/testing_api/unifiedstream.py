# import streamlit as st
# from streamlit_option_menu import option_menu
# from audiorecorder import audiorecorder
# import tempfile
# import speech_recognition as sr
# import subprocess
# import sys
# from io import BytesIO
# import os

# # Sidebar menu
# with st.sidebar:
#     selected = option_menu(
#         "SpeakTest",
#         ["Voice Command", "Site Validator"],
#         icons=["mic", "code"],
#         menu_icon="cast",
#         default_index=0
#     )

# # --------------------------------------
# # PAGE 1: Voice Command
# # --------------------------------------
# if selected == "Voice Command":
#     st.title("SpeakTest")

#     audio = audiorecorder("Click to record", "Recording...")

#     if len(audio) > 0:
#         buffer = BytesIO()
#         audio.export(buffer, format="wav")
#         st.audio(buffer.getvalue(), format="audio/wav")

#         with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
#             audio.export(f.name, format="wav")
#             audio_path = f.name

#         recognizer = sr.Recognizer()
#         with sr.AudioFile(audio_path) as source:
#             audio_data = recognizer.record(source)
#             try:
#                 text = recognizer.recognize_google(audio_data)
#                 st.success("Speech recognition successful")
#             except Exception as e:
#                 st.error(f"Speech recognition failed: {e}")
#                 text = ""

#         editable_text = st.text_area("Edit or enter the text below:", value=text, height=100)

#         if st.button("Submit"):
#             try:
#                 result = subprocess.run(
#                     [sys.executable, "swagwithstream.py", editable_text],
#                     capture_output=True,
#                     text=True,
#                     encoding="utf-8",
#                     check=True,
#                     cwd="D:/Code/testing",
#                     env={**os.environ, "pythonioencoding": "utf-8"}
#                 )
#                 if result.returncode == 0:
#                     st.code(result.stdout)
#                 else:
#                     st.error(f"Script error:\n{result.stderr}")
#             except Exception as ex:
#                 st.error(f"Failed to run script: {ex}")

# # --------------------------------------
# # PAGE 2: Site Validator
# # --------------------------------------
# elif selected == "Site Validator":
#     st.title("Task Runner for Site Validation")

#     task_input = st.text_area("Enter Task Instructions:", height=300)

#     if st.button("Run Validation"):
#         if task_input.strip():
#             try:
#                 result = subprocess.run(
#                     [sys.executable, "sitewithstream.py", task_input],
#                     capture_output=True,
#                     text=True,
#                     encoding="utf-8",
#                     check=True,
#                     cwd="D:/Code/testing",
#                     env={**os.environ, "pythonioencoding": "utf-8"}
#                 )

#                 if result.returncode == 0:
#                     st.success("Validation completed successfully!")
#                     st.code(result.stdout)
#                 else:
#                     st.error("Validation script returned error.")
#                     st.code(result.stderr)
#             except Exception as e:
#                 st.error(f"Failed to run validation script: {e}")
#         else:
#             st.warning("Please enter a task before running.")
import streamlit as st
from streamlit_option_menu import option_menu

# Import the two page files as modules
import streamvoice
import streamtext
import streamjira

# Create sidebar menu
with st.sidebar:
    selected = option_menu(
        "TCS A.S.C.E.N.D",
        ["SpeakTest", "Site Validator","Jira Test"],
        icons=["mic", "textarea-t", "link-45deg"],
        menu_icon="cast",
        default_index=0
    )

# Call the corresponding render() function
if selected == "SpeakTest":
    streamvoice.render()

elif selected == "Site Validator":
    streamtext.render()

elif selected == "Jira Test":
    streamjira.render()

