'use client';

import React, { useState, useRef } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Mic, Loader2 } from 'lucide-react';

// 👇 Add this to avoid red underline
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }

   interface SpeechRecognitionEvent extends Event {
    results: SpeechRecognitionResultList;
  }

  interface SpeechRecognitionErrorEvent extends Event {
    error: string;
  }
}

type SpeechRecognition = any;
type VoiceTranscriberProps = {
  transcribedText: string;
  setTranscribedText: (text: string) => void;
};

const VoiceTranscriber: React.FC<VoiceTranscriberProps> = ({ transcribedText, setTranscribedText }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  // const [transcribedText, setTranscribedText] = useState('');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const handleStartRecording = () => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsRecording(true);
      setIsProcessing(true);
      setTranscribedText('');
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
  const speechResult = event.results[0][0].transcript;
  setTranscribedText(speechResult);
};

  recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
  console.error('Speech recognition error:', event.error);
  setTranscribedText('Error: ' + event.error);
};

    recognition.onend = () => {
      setIsRecording(false);
      setIsProcessing(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleStopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  return (
    <div className="flex flex-row w-full mx-auto gap-3">
      {/* Left: Recorder Button */}
      <div className="bg-[#2E2D2D] h-[16vh] w-20/5 flex items-center justify-center rounded-md">
        <Button className='bg-[#64acff]  rounded-full'
          variant={isRecording ? 'destructive' : 'default'}
          onClick={isRecording ? handleStopRecording : handleStartRecording}
        >
          <Mic className=" h-4 w-4 text-white " />

        </Button>
        <span className="ml-2 text-white">
          {isRecording ? 'Recording...' : 'Start Recording'}
        </span>
      </div>
<p style={{borderRadius:"50px", height:"6vh", width:"25vw",border:"1px solid grey", textAlign:"center", paddingTop:"5px", marginTop:"15px" }}>or</p>
      {/* Right: Text Area or Loader */}
      <div className="bg-[#2E2D2D] h-[16vh] w-20/5 flex items-center justify-center rounded-md" style={{marginLeft:"0px"}}>
        {isRecording && isProcessing ? (
         
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className='animate-spin'> <svg xmlns="http://www.w3.org/2000/svg" width="23.242" height="23.242" viewBox="0 0 23.242 23.242">
              <g id="bx-loader" transform="translate(-16 -16)">
                <path id="Path_75" data-name="Path 75" d="M16,26.459h5.811v2.324H16Zm17.432,0h5.811v2.324H33.432Zm-6.973,6.973h2.324v5.811H26.459Zm0-17.432h2.324v5.811H26.459Zm-7.877,4.225,1.643-1.643,4.109,4.109-1.643,1.643ZM36.66,35.017,35.017,36.66l-4.109-4.109,1.643-1.643ZM22.691,30.908l1.643,1.643L20.225,36.66l-1.643-1.643Zm8.216-8.217,4.109-4.108,1.643,1.644-4.109,4.108Z" fill="#00c4ff"/>
              </g>
            </svg></span>
            {/* <Loader2 className="animate-spin h-5 w-5" /> */}
            Recognizing your voice
          </div>
        ) : (
          <Textarea
            className="w-full h-[16vh] "
            rows={6}
            placeholder="Enter your prompt here..."
            value={transcribedText}
            onChange={(e) => setTranscribedText(e.target.value)}
          />
        )}
      </div>
    </div>
  );
};

export default VoiceTranscriber;
