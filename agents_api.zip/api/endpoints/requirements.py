from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Optional

from agents.extractor_agent import ExtractorAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.gherkin_agent import GherkinAgent
from agents.testcase_agent import TestCaseAgent
from agents.traceability_agent import TraceabilityAgent
from tools.llm_utils import call_gemini

router = APIRouter()

class FilePathRequest(BaseModel):
    file_path: str

@router.post("/extract")
async def extract_requirements(request: FilePathRequest):
    agent = ExtractorAgent(llm_caller=call_gemini)
    extracted = agent.run(request.file_path)
    # return extracted
    return {"extracted_requirements": extracted}
#####################################################################################################

class RequirementsRequest(BaseModel):
    extracted_requirements: List[Dict]

@router.post("/classify")
async def classify_requirements(request: RequirementsRequest):
    agent = ClassifierAgent(llm_caller=call_gemini)
    classified = agent.run(request.extracted_requirements)
    return classified

#####################################################################################################

class ClassifiedRequirementsRequest(BaseModel):
    classified_requirements: List[Dict]

@router.post("/validate")
async def validate_requirements(request: ClassifiedRequirementsRequest):
    agent = ValidationAgent(llm_caller=call_gemini)
    validated = agent.run(request.model_dump())
    return validated
#####################################################################################################

class ValidatedRequirementsRequest(BaseModel):
    validated_requirements: List[Dict]


@router.post("/user_stories")
async def generate_user_stories(request: ValidatedRequirementsRequest):
    agent = UserStoryAgent(llm_caller=call_gemini)
    user_stories = agent.run(request.model_dump())
    return user_stories

######################################################################################################

class UserStoriesRequest(BaseModel):
    user_stories: List[Dict]

@router.post("/gherkin")
async def generate_gherkin(request: UserStoriesRequest):
    agent = GherkinAgent(llm_caller=call_gemini)
    gherkin = agent.run(request.model_dump())
    return gherkin
######################################################################################################

@router.post("/test_cases")
async def generate_test_cases(request: UserStoriesRequest):
    agent = TestCaseAgent(llm_caller=call_gemini)
    test_cases = agent.run(request.model_dump())
    return test_cases
#######################################################################################################

class TraceabilityRequest(BaseModel):
    classified_requirements: List[Dict]
    validated_requirements: Optional[List[Dict]]
    user_stories: Optional[List[Dict]]
    gherkin_scenarios: Optional[List[Dict]]
    test_cases: Optional[List[Dict]]

# @router.post("/traceability")
# async def generate_traceability(request: TraceabilityRequest):
#     agent = TraceabilityAgent()  # ✅ no args since class doesn’t support it
#     traceability = agent.run(request.model_dump())
#     return traceability

@router.post("/traceability")
async def generate_traceability(request: TraceabilityRequest):
    inputs = {
        "classified": request.classified_requirements or [],
        "validated": request.validated_requirements or [],
        "user_stories": request.user_stories or [],
        "gherkin_scenarios": request.gherkin_scenarios or [],
        "test_cases": request.test_cases or [],
    }
    agent = TraceabilityAgent()
    traceability = agent.run(inputs)
    return traceability
