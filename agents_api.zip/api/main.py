from fastapi import FastAPI
from api.endpoints import requirements
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(requirements.router)

# uvicorn api.main:app --reload
# uvicorn api.main:app --timeout-keep-alive 120
