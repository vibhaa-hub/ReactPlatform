from typing import List, Dict, Callable
import re
import json
from tools.prompt_utils import extract_clean_json

class ValidationAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def _rule_based_issues(self, text: str) -> List[str]:
        issues = []
        if len(text.strip().split()) < 5:
            issues.append("Too short")
        if re.search(r"\betc\.|\bstuff\b|\bthings\b|\bshould handle\b", text.lower()):
            issues.append("Vague phrasing")
        return issues

    def run(self, inputs: Dict) -> Dict:
        print(inputs)
        requirements = inputs["classified_requirements"]

        # Step 1: Build the input list for Gemini
        req_list = [
            {"id": req["requirement_id"], "text": req["requirement_text"]}
            for req in requirements
        ]

        # Step 2: Prompt
        formatted = "\n".join([
            f'{r["id"]}: {r["text"]}' for r in req_list
        ])

        prompt = f"""
        You are a requirement quality checker. You are validating business requirements.

        Below is a list of requirements. 
        For each requirement, return:
        - requirement_id
        - llm_check_passed: true if the requirement is clear, testable, and unambiguous
        - issues: list of issues if not valid (e.g. vague, not measurable)
        - justification: a short reason for why it's valid (if passed)

        Respond in this raw JSON format:
        [
        {{
            "requirement_id": "REQ-001",
            "llm_check_passed": true,
            "issues": [],
            "justification": "The requirement is clearly defined and testable."
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()

        llm_response = self.llm_caller(prompt)
        try:
            # llm_results = json.loads(llm_response)
            llm_results = extract_clean_json(llm_response)
        except Exception:
            llm_results = []

        # Step 3: Map by ID
        result_map = {r["requirement_id"]: r for r in llm_results}

        # Step 4: Merge with original list
        for req in requirements:
            #  rule_issues = self._rule_based_issues(req["requirement_text"])
            llm_result = result_map.get(req["requirement_id"], {
                "llm_check_passed": False,
                "issues": ["LLM did not return result"],
                "justification": "LLM did not return result"
            })

            # combined_issues = sorted(set(rule_issues + llm_result.get("issues", [])))
            combined_issues = sorted(set(llm_result.get("issues", [])))

            req["validation"] = {
                "llm_check_passed": llm_result.get("llm_check_passed", False),
                "issues": combined_issues,
                "justification": llm_result.get("justification", "")
            }

        return {"validated_requirements": requirements}